use April25;

delete from Employee;

Insert into Employee(Empno, Name, Gender, Dept, Desig, Basic) 
values(1, 'Sadhana','FEMALE','Sql','Expert',88323),
(2,'Anil','MALE','Java','Programmer',88411),
(3,'Hari','MALE','React','Manager',88311),
(4,'Priyadarshan','MALE','Java','Expert',88114),
(5, 'Mayuri','FEMALE','Sql','Expert',82355),
(6,'Meghana','FEMALE','Sql','Developer',88424);