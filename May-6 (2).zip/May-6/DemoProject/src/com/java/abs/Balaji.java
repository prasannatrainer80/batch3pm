package com.java.abs;

public class Balaji extends Training {

	@Override
	public void name() {
		System.out.println("Name is Balaji...");
	}

	@Override
	public void email() {
		System.out.println("Email is balaji@gmail.com");
	}

}
