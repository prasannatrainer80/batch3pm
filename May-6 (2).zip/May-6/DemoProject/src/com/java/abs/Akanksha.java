package com.java.abs;

public class Akanksha extends Emp {

	public Akanksha(int empno, String name, double basic) {
		super(empno, name, basic);
		// TODO Auto-generated constructor stub
	}

}
