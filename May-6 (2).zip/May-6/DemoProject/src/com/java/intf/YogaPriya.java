package com.java.intf;

public class YogaPriya implements ITraining {

	@Override
	public void name() {
		System.out.println("Name is YogaPriya...");
	}

	@Override
	public void email() {
		System.out.println("Email is yoga@gmail.com");
	}

}
