package com.java.intf;

public interface ITraining {
	void name();
	void email();
}
