package com.java.intf;

public class Pratham implements ITraining{

	@Override
	public void name() {
		System.out.println("Name is Pratham...");
	}

	@Override
	public void email() {
		System.out.println("Email is pratham@gmail.com");
	}

}
