package com.java.intf;

public class Madhusree implements ITraining {

	@Override
	public void name() {
		System.out.println("Name is Madhusree...");
	}

	@Override
	public void email() {
		System.out.println("Email is madhu@gmail.com");
	}

}
