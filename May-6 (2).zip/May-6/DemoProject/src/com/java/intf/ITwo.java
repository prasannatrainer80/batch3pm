package com.java.intf;

public interface ITwo {
	void email();
}
