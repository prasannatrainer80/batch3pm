package com.java.sup;

final class Admin {
	void show() {
		
	}
}

class Prasanna extends Admin {
	
}
public class Fc {

}
