package com.java.sup;

public class Quiz1 {

	public static void main(String[] args) {
		String s1="Balaji", s2="Hari", s3="Balaji";
		System.out.println(s1==s3);
		System.out.println(s1.equals(s3));
	}
}
