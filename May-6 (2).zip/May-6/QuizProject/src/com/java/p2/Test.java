package com.java.p2;

import com.java.p1.Hello;

public class Test {

	public void show() {
		Hello hello = new Hello();
		System.out.println(hello.publicString);
	}
}
