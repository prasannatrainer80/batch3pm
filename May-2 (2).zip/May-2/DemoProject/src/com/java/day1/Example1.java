package com.java.day1;

public class Example1 {

	public static void main(String[] args) {
		int x = 12;
		String str = "Hexaware";
		double y = 12.5;
		
		System.out.println("X value is  " +x);
		System.out.println("Company is  " +str);
		System.out.println("Y value is  " +y);
	}
}
