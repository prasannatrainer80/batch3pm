package com.java.day1;

public class Quiz1 {

	public static void main(String[] args) {
		int x=12;
		System.out.println(x++);
	}
}
