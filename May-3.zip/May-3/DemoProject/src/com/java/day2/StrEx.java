package com.java.day2;

public class StrEx {
	public static void main(String[] args) {
		String str ="Hello";
		str.concat(" World");
		System.out.println(str);
	}
}
