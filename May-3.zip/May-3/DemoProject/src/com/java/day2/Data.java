package com.java.day2;

public class Data {

	public void sayHello() {
		System.out.println("Welcome to Java Programming...");
	}
	
	void topic() {
		System.out.println("Java OOPS going on...");
	}
	
	private void trainer() {
		System.out.println("Trainer is Prasanna...");
	}
}
