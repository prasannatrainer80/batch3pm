package com.java.lms;

import java.util.Date;

public class Customer {

	private int customerId;
	private String customerName;
	private String gender;
	private Date dateOfBirth;
	private String status;
	private double billAmount;
}
