function show() {
   var sname= prompt("Enter Your Name  ");
   alert("Entered Name is  " +sname);
}