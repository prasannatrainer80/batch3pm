function show() {
    var str = confirm("Are You Sure...")
    if(str==true) {
        alert("You are Confirmed...")
    } else {
        alert("Its Not Confirmed...");
    }
    // alert(str);
}
