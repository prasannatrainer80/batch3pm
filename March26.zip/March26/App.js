import logo from './logo.svg';
import EmployShow from './components/employshow/employshow';

function App() {
  return (
    <div className="App">
      <EmployShow />
    </div>
  );
}

export default App;
