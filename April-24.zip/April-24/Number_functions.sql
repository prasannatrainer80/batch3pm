-- Number Functions 

-- Abs() : Absolute value 

select abs(-12);

-- power(n,m) : Returns n power m value 

select power(2,3);

-- sqrt() : Display's the sqrt value 

select sqrt(49);

-- ceiling() : returns the greatest integer value 

select ceiling(12.000000001);

-- floor() : Returns smallest integer value 

select floor(12.9999999999999);