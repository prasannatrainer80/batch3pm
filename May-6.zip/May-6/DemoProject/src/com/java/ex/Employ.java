package com.java.ex;

public class Employ {

	int empno;
	String name;
	double basic;
	
	public void show() {
		System.out.println("Employ No  " +empno);
		System.out.println("Name   " +name);
		System.out.println("Basic  " +basic);
	}
}
