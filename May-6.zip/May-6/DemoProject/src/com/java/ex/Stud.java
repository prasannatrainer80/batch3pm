package com.java.ex;

public class Stud {

	int sid;
	String name;
	double cgpa;
	
	@Override
	public String toString() {
		return "Stud [sid=" + sid + ", name=" + name + ", cgpa=" + cgpa + "]";
	}
	
	
}
