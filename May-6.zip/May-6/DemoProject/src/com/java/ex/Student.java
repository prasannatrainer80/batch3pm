package com.java.ex;

public class Student {

	int sid;
	String name;
	double cgpa;
	
	public void showStudentInfo() {
		System.out.println("Student Id  " +sid);
		System.out.println("Student Name  " +name);
		System.out.println("Cgpa  " +cgpa);
	}
}
